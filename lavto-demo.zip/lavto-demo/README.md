# Лавто: демо-концепт сайта СТО

Статичная страница (`index.html`), Tailwind и шрифты подключаются с CDN. Не официальный сайт заведения.

## Публикация на GitHub Pages
1. Создайте репозиторий на github.com и загрузите все файлы из этой папки.
2. Settings → Pages → Build and deployment → Source: Deploy from a branch.
3. Branch: `main`, папка `/ (root)` → Save.
4. Через 1-2 минуты сайт откроется на `https://<ваш-логин>.github.io/<репозиторий>/`.

## Пересборка
`node build.js` собирает `index.html` из `src/template.html` и `content/lavto.json`.
Фото: положите jpg/png/webp в `photos/lavto/`, и они встроятся в страницу.
