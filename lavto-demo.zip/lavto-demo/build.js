const fs = require('fs');
const path = require('path');

const esc = s => String(s ?? '').replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
const get = (ctx, p) => p.split('.').reduce((o, k) => (o == null ? undefined : o[k]), ctx);
const truthy = v => Array.isArray(v) ? v.length > 0 : Boolean(v);

function render(tpl, ctx) {
  tpl = tpl.replace(/\{\{#each ([\w.]+)\}\}([\s\S]*?)\{\{\/each\}\}/g, (_, p, body) =>
    (get(ctx, p) || []).map(item =>
      render(body, { ...ctx, ...(typeof item === 'object' ? item : {}), this: item })).join(''));
  tpl = tpl.replace(/\{\{#if ([\w.]+)\}\}([\s\S]*?)\{\{\/if\}\}/g, (_, p, body) =>
    truthy(get(ctx, p)) ? render(body, ctx) : '');
  tpl = tpl.replace(/\{\{\{([\w.]+)\}\}\}/g, (_, p) => get(ctx, p) ?? '');
  return tpl.replace(/\{\{([\w.]+)\}\}/g, (_, p) => esc(get(ctx, p)));
}

const ICONS = {
  pulse: '<path d="M3 12h4l2-6 4 12 2-6h6"/>',
  oil: '<path d="M12 3s6 6.5 6 11a6 6 0 0 1-12 0c0-4.5 6-11 6-11z"/>',
  brake: '<circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="3"/><circle cx="12" cy="6.5" r=".8"/><circle cx="12" cy="17.5" r=".8"/><circle cx="6.5" cy="12" r=".8"/><circle cx="17.5" cy="12" r=".8"/>',
  bolt: '<path d="M13 2 4 14h7l-1 8 9-12h-7z"/>',
  tow: '<path d="M2 16V8h11v8M13 11h4l3 3v2M2 16h2m10 0h2"/><circle cx="7" cy="17" r="2"/><circle cx="17" cy="17" r="2"/>',
  wrench: '<path d="M14.7 6.3a4 4 0 0 0 5 5L11 20a2.1 2.1 0 0 1-3-3z"/><path d="M14.7 6.3 12 9"/>'
};
const icon = k => `<svg viewBox="0 0 24 24" width="26" height="26" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${ICONS[k] || ICONS.wrench}</svg>`;

const root = __dirname;
const tpl = fs.readFileSync(path.join(root, 'src/template.html'), 'utf8');
const files = fs.readdirSync(path.join(root, 'content')).filter(f => f.endsWith('.json') && f !== '_example.json');
const sites = files.map(f => JSON.parse(fs.readFileSync(path.join(root, 'content', f), 'utf8')));

sites.forEach((s, n) => {
  const t = s.theme;
  const tiles = [t.accent, t.alt, t.blue, t.green, t.orange];
  const q = encodeURIComponent(s.mapQuery || s.visit.address);
  s.routeUrl = `https://www.google.com/maps/dir/?api=1&destination=${q}`;
  s.mapEmbed = `https://www.google.com/maps?q=${q}&output=embed&hl=ru`;
  s.telHref = s.phone ? `tel:${s.phone}` : '';
  s.tz = s.tz || 'UTC';
  s.btnCols = s.phone ? 'grid-cols-2' : 'grid-cols-1';
  s.scheduleJson = JSON.stringify(s.schedule || null);
  s.showPrices = s.services.some(x => x.price);
  s.noPrices = !s.showPrices;
  s.services.forEach((x, i) => {
    x.priceText = x.price || s.priceFallback || 'Уточняйте';
    x.iconSvg = icon(x.icon);
    x.tile = tiles[i % tiles.length];
  });
  s.praise.forEach((x, i) => { x.color = [t.accent, t.alt, t.blue][i % 3]; });
  const dir = path.join(root, 'photos', s.slug);
  s.photos = fs.existsSync(dir)
    ? fs.readdirSync(dir).filter(f => /\.(jpe?g|png|webp)$/i.test(f)).sort().map(f => {
        const ext = path.extname(f).slice(1).toLowerCase().replace('jpg', 'jpeg');
        return `data:image/${ext};base64,` + fs.readFileSync(path.join(dir, f)).toString('base64');
      })
    : [];
  const out = sites.length === 1 ? 'index.html' : `${s.slug}.html`;
  fs.writeFileSync(path.join(root, out), render(tpl, s));
  console.log('ok', out);
});
